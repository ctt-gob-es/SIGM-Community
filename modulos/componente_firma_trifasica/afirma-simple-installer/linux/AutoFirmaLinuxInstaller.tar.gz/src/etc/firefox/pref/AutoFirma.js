pref("network.protocol-handler.app.afirma","/usr/bin/AutoFirma");
pref("network.protocol-handler.warn-external.afirma",false);
pref("network.protocol-handler.external.afirma",true);

