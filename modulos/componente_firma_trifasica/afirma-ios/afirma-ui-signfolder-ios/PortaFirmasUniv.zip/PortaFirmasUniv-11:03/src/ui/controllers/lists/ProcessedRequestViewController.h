//
//  ProcessedRequestViewController.h
//  PortaFirmasUniv
//
//  Created by Antonio Fiñana Sánchez on 23/10/12.
//  Copyright (c) 2012 Atos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RequestListXMLController.h"
#import "WSDataController.h"
#import "BaseListTVC.h"

@interface ProcessedRequestViewController : BaseListTVC

@end
