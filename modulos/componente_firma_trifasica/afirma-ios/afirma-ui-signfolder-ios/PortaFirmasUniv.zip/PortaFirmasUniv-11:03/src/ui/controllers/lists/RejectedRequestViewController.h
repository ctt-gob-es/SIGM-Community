//
//  RejectedRequestViewController.h
//  PortaFirmasUniv
//
//  Created by Antonio Fiñana Sánchez on 06/11/12.
//  Copyright (c) 2012 Atos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseListTVC.h"

@interface RejectedRequestViewController : BaseListTVC

@end
