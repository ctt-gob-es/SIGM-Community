//
//  NoCertificatesViewController.h
//  PortaFirmasUniv
//
//  Created by Antonio Fiñana on 26/11/12.
//  Copyright (c) 2012 Atos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoCertificatesViewController : UITableViewController

@end
